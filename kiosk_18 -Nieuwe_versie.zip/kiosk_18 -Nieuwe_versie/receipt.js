// Function to load receipt details
function loadReceipt() {
    const receiptItemsContainer = document.getElementById("receiptItems");
    const orderItems = JSON.parse(localStorage.getItem('orderItems'));
    const totalAmount = localStorage.getItem('totalAmount');

    let totalPrice = 0



    console.log(orderItems);
    if (orderItems && totalAmount) {
        orderItems.forEach((item, index) => {
            const receiptItemElement = document.createElement("div");
            const orderItemId = `receipt-item-${index}`;
            receiptItemElement.id = orderItemId;
            console.log(item);
            totalPrice += item.price;
            console.log(totalPrice);
            receiptItemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}" style="width: 50px; vertical-align: middle; margin-right: 10px;">
                ${item.name} - €${item.price.toFixed(2)}
                <button class="remove-button" onclick="removeFromReceipt('${orderItemId}', ${item.price})">Remove</button>
            `;
            receiptItemsContainer.appendChild(receiptItemElement);
        });

        const receiptTotalAmount = document.getElementById("receiptTotalAmount");
        receiptTotalAmount.textContent = `Total : €${totalPrice}`;
        console.log(totalAmount);
    } else {
        alert("No order details found!");
        window.location.href = 'index.html'; // Redirect to home if no order details
    }
}

// Function to remove item from the receipt
function removeFromReceipt(orderItemId, itemPrice) {
    const orderItem = document.getElementById(orderItemId);
    if (orderItem) {
        orderItem.remove();
        updateReceiptTotalAmount(itemPrice);
    }
}

// Function to update the total amount display on the receipt page
function updateReceiptTotalAmount(itemPrice) {
    const receiptTotalAmountElement = document.getElementById("receiptTotalAmount");
    let totalAmount = parseFloat(receiptTotalAmountElement.textContent.split('€')[1]);
    totalAmount -= itemPrice;
    receiptTotalAmountElement.textContent = `Total Amount: € ${totalAmount.toFixed(2)}`;
    

    // Update localStorage
    const orderItems = JSON.parse(localStorage.getItem('orderItems')).filter(item => item.price !== itemPrice);
    localStorage.setItem('orderItems', JSON.stringify(orderItems));
    localStorage.setItem('totalAmount', totalAmount.toFixed(2));
}

// Function to go back to the main page
function goBack() {
    window.location.href = 'index.html';
}

// Load receipt details on page load
window.onload = loadReceipt;

// Function to display menu items of a specific category using IDs until no more IDs are left
function displayCategoryWithIDs(category) {
    const menuItemsContainer = document.getElementById("menuItems");
    menuItemsContainer.innerHTML = '';

    let index = 0;
    let item = getMenuItemAt(index, category);

    // Keep generating menu items until no more IDs are left
    while (item) {
        const menuItemElement = document.createElement("div");
        menuItemElement.classList.add("menu-item");

        // Create image element
        const imgElement = document.createElement("img");
        imgElement.src = item.image;
        imgElement.alt = item.name;
        imgElement.style.width = "50%"; // Set image width (adjust as needed)
        menuItemElement.appendChild(imgElement);

        // Create item details (name and price)
        const itemDetails = document.createElement("div");
        itemDetails.classList.add("item-details");
        itemDetails.innerHTML = `
            <p>${item.name}</p>
            <p>€ ${item.price}</p>
            <button class="info-button" onclick="showProductInfo('${item.name}', '${item.description}', '${item.image}'); event.stopPropagation();">Info</button>
        `;
        menuItemElement.appendChild(itemDetails);

        menuItemElement.onclick = () => {
            addToOrder(item);
        };

        menuItemsContainer.appendChild(menuItemElement);

        // Move to the next item
        index++;
        item = getMenuItemAt(index, category);
    }
}

// Function to get menu item by index and category
function getMenuItemAt(index, category) {
    const filteredItems = menu.filter(item => item.category === category);
    return filteredItems[index];
}

// Display initial category (default: Fast Food) with IDs until no more IDs are left
function displayFastFoodWithIDs() {
    displayCategoryWithIDs('Fast Food');
}

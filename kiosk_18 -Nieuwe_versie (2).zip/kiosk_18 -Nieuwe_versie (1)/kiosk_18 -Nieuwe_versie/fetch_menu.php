<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiosk";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("SELECT id, title AS name, img AS image, info AS description, price, category FROM menu");
    $stmt->execute();

    $menu = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($menu);

} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

$conn = null;
?>

// Function to load order details from localStorage and display on receipt
function loadOrderDetails() {
    const receiptItemsContainer = document.getElementById("receiptItems");
    const totalAmountDisplay = document.getElementById("receiptTotalAmount");

    // Load order items from localStorage
    const orderItems = JSON.parse(localStorage.getItem('orderItems'));
    const totalAmount = parseFloat(localStorage.getItem('totalAmount'));

    // Clear previous receipt items
    receiptItemsContainer.innerHTML = '';

    // Display each order item on the receipt
    if (orderItems && totalAmount) {
        orderItems.forEach(item => {
            const receiptItem = document.createElement("div");
            receiptItem.classList.add("receipt-item");
            receiptItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}" class="receipt-item-image">
                <div class="receipt-item-details">
                    <p class="receipt-item-name">${item.name}</p>
                    <p class="receipt-item-price">€ ${item.price.toFixed(2)}</p>
                </div>
            `;
            receiptItemsContainer.appendChild(receiptItem);
        });

        // Display total amount
        totalAmountDisplay.textContent = `Total Amount: €${totalAmount.toFixed(2)}`;
    } else {
        receiptItemsContainer.textContent = "No items in the order.";
        totalAmountDisplay.textContent = "Total Amount: €0.00";
    }
}

// Function to go back to the previous page
function goBack() {
    window.history.back();
}

// Load order details on page load
window.onload = loadOrderDetails;
